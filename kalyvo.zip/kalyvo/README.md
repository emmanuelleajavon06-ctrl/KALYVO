# KALYVO — Gérez mieux. Gagnez mieux.
Application de gestion pour petites entreprises (Sénégal). **Lot 1 : cœur financier.**

## Fonctionnalités (Lot 1)
Inscription / connexion (mot de passe haché), assistant de création d'entreprise, essai gratuit de 30 jours (démarre à la création de l'entreprise, blocage ensuite),
produits avec unités et stock (Disponible / Faible / Rupture), caisse de vente avec paiement mixte (Espèces, Wave, Orange Money, Crédit),
caisse (entrées/sorties), dépenses, clients (pour les ventes à crédit), tableau de bord (CA, bénéfice brut, bénéfice net, marge, créances, caisse, stock, top produits, alertes).

## Moteur financier
Chaque vente est UNE transaction atomique : vente + lignes + stock − quantité + mouvements de stock + paiements + entrées de caisse + créance.
Tout réussit ou rien n'est enregistré. CA = total des ventes ; Bénéfice brut = CA − coût d'achat ; Bénéfice net = brut − dépenses.

## Stack
Python 3 / Flask, SQLite, HTML/CSS/JS. Mots de passe : scrypt (Werkzeug).

## Lancer en local
pip install -r requirements.txt && python app.py   (http://127.0.0.1:5000)

## Déployer sur Render
Web Service, build `pip install -r requirements.txt`, start `gunicorn app:app`.
Variables : SECRET_KEY (long, aléatoire), DATA_DIR=/data. Ajouter un Disk monté sur /data, sinon les données sont perdues à chaque redémarrage.

## Limites actuelles (à venir)
Dettes et paiements de dette, objectifs, analytics/rapports, Mobile Money/crédits, abonnement Wave manuel et espace admin, employés/rôles, notifications, journal d'activité (l'écriture est faite, l'écran non),
landing page, démo, mot de passe oublié. PostgreSQL non branché. Pas de compte démo à ce stade.
