import os, sqlite3, time
from functools import wraps
from flask import Flask, request, session, jsonify, send_from_directory, g
from werkzeug.security import generate_password_hash as gh, check_password_hash as ch

app = Flask(__name__, static_folder='static')
app.secret_key = os.environ.get('SECRET_KEY', 'dev-change-me')
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax', PERMANENT_SESSION_LIFETIME=86400 * 365)
DB = os.path.join(os.environ.get('DATA_DIR', '.'), 'kalyvo.db')
METHODS = ['Espèces', 'Wave', 'Orange Money', 'Crédit']
DAY = 86400

def db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB); g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close(_):
    d = g.pop('db', None)
    if d: d.close()

def q(sql, a=(), one=False):
    r = db().execute(sql, a).fetchall()
    return (r[0] if r else None) if one else r

def S(sql, a=()):
    return q(sql, a, one=True)[0] or 0

with sqlite3.connect(DB) as c:
    c.executescript('''
    create table if not exists users(id integer primary key, name text, phone text, email text unique, pw text, created real);
    create table if not exists businesses(id integer primary key, user_id int, name text, owner text, phone text, country text, city text, address text, sector text, currency text default 'FCFA', trial_end real, sub_until real default 0, created real);
    create table if not exists products(id integer primary key, biz int, name text, ref text, cat text, supplier text, buy real, sell real, qty real default 0, unit text, alert real default 5, active int default 1);
    create table if not exists stock_moves(id integer primary key, biz int, product_id int, qty real, type text, ref text, created real);
    create table if not exists customers(id integer primary key, biz int, name text, phone text default '', created real);
    create table if not exists sales(id integer primary key, biz int, num text, customer_id int, subtotal real, discount real, total real, cost real default 0, created real);
    create table if not exists sale_items(id integer primary key, sale_id int, product_id int, name text, qty real, price real, cost real);
    create table if not exists sale_payments(id integer primary key, sale_id int, method text, amount real);
    create table if not exists cash(id integer primary key, biz int, type text, amount real, method text, cat text, label text, ref_type text, ref_id int, created real);
    create table if not exists expenses(id integer primary key, biz int, cat text, label text, amount real, method text, created real);
    create table if not exists debts(id integer primary key, biz int, customer_id int, sale_id int, amount real, paid real default 0, due real, created real);
    create table if not exists audit(id integer primary key, biz int, user text, action text, detail text, created real);''')

def err(m, c=400): return jsonify(error=m), c
def num(x, d=0):
    try: return float(x)
    except (TypeError, ValueError): return d
def fmt(n): return f'{int(n):,}'.replace(',', ' ')

def audit(action, detail=''):
    db().execute('insert into audit(biz,user,action,detail,created) values(?,?,?,?,?)', (g.b['id'] if g.get('b') else None, g.u['name'], action, detail, time.time()))

def status(b):
    now = time.time(); end = max(b['trial_end'], b['sub_until'])
    return dict(active=now < end, days_left=max(0, -(-int(end - now) // DAY)), subscribed=b['sub_until'] > now, trial_end=b['trial_end'], sub_until=b['sub_until'])

def api(gate=True):
    def deco(f):
        @wraps(f)
        def w(*a, **k):
            u = q('select * from users where id=?', (session.get('uid'),), one=True) if session.get('uid') else None
            if not u: return err('Veuillez vous connecter', 401)
            g.u = u; g.b = q('select * from businesses where user_id=?', (u['id'],), one=True)
            if gate:
                if not g.b: return err('Créez d\'abord votre entreprise', 409)
                if not status(g.b)['active']: return err('Votre essai gratuit est terminé', 402)
            return f(*a, **k)
        return w
    return deco

@app.errorhandler(500)
def e500(_): return err('Une erreur est survenue. Vos données n\'ont pas été modifiées, réessayez.', 500)

@app.route('/')
def home(): return send_from_directory('static', 'index.html')

@app.get('/healthz')
def hz(): return 'ok'

@app.post('/api/register')
def register():
    d = request.json or {}; email = (d.get('email') or '').strip().lower(); name = (d.get('name') or '').strip()
    if not name or '@' not in email or len(d.get('password', '')) < 8: return err('Nom, email valide et mot de passe (8 caractères min.) requis')
    if q('select 1 from users where email=?', (email,), one=True): return err('Cet email a déjà un compte')
    c = db().execute('insert into users(name,phone,email,pw,created) values(?,?,?,?,?)', (name, (d.get('phone') or '').strip(), email, gh(d['password']), time.time()))
    db().commit(); session.permanent = True; session['uid'] = c.lastrowid
    return jsonify(ok=True)

@app.post('/api/login')
def login():
    d = request.json or {}; u = q('select * from users where email=?', ((d.get('email') or '').strip().lower(),), one=True)
    if not u or not ch(u['pw'], d.get('password', '')): return err('Email ou mot de passe incorrect', 401)
    session.permanent = True; session['uid'] = u['id']; return jsonify(ok=True)

@app.post('/api/logout')
def logout(): session.clear(); return jsonify(ok=True)

@app.get('/api/me')
@api(False)
def me():
    b = g.b; return jsonify(user=dict(name=g.u['name'], email=g.u['email']), business=dict(b) if b else None, **(status(b) if b else {}))

SECTORS = ['multiservice', 'boutique', 'commerce', 'resto', 'salon', 'atelier', 'agriculture', 'autre']
@app.post('/api/business')
@api(False)
def business():
    if g.b: return err('Votre entreprise existe déjà')
    d = request.json or {}; n = (d.get('name') or '').strip()
    if not n: return err('Le nom de l\'entreprise est requis')
    sec = d.get('sector') if d.get('sector') in SECTORS else 'autre'; now = time.time()
    db().execute('insert into businesses(user_id,name,owner,phone,country,city,address,sector,trial_end,created) values(?,?,?,?,?,?,?,?,?,?)',
                 (g.u['id'], n, d.get('owner') or g.u['name'], d.get('phone', ''), d.get('country') or 'Sénégal', d.get('city', ''), d.get('address', ''), sec, now + 30 * DAY, now))
    db().commit(); return jsonify(ok=True)

PF = ['name', 'ref', 'cat', 'supplier', 'buy', 'sell', 'unit', 'alert']
@app.route('/api/products', methods=['GET', 'POST'])
@api()
def products():
    b = g.b['id']
    if request.method == 'POST':
        d = request.json or {}
        if not (d.get('name') or '').strip() or num(d.get('sell'), -1) < 0 or num(d.get('buy'), -1) < 0: return err('Nom, prix d\'achat et prix de vente requis')
        qty = max(0, num(d.get('qty')))
        c = db().execute('insert into products(biz,name,ref,cat,supplier,buy,sell,qty,unit,alert) values(?,?,?,?,?,?,?,?,?,?)',
                         (b, d['name'].strip(), d.get('ref', ''), d.get('cat', ''), d.get('supplier', ''), num(d['buy']), num(d['sell']), qty, d.get('unit') or 'unité', num(d.get('alert'), 5)))
        if qty: db().execute('insert into stock_moves(biz,product_id,qty,type,ref,created) values(?,?,?,?,?,?)', (b, c.lastrowid, qty, 'STOCK INITIAL', '', time.time()))
        audit('Produit créé', d['name']); db().commit(); return jsonify(id=c.lastrowid)
    return jsonify([dict(x) for x in q('select * from products where biz=? and active=1 order by id desc', (b,))])

@app.route('/api/products/<int:i>', methods=['PUT', 'DELETE'])
@api()
def product1(i):
    p = q('select * from products where id=? and biz=? and active=1', (i, g.b['id']), one=True)
    if not p: return err('Produit introuvable', 404)
    if request.method == 'DELETE':
        db().execute('update products set active=0 where id=?', (i,)); audit('Produit supprimé', p['name'])
    else:
        d = request.json or {}
        db().execute('update products set name=?,ref=?,cat=?,supplier=?,buy=?,sell=?,unit=?,alert=? where id=?',
                     (d.get('name') or p['name'], d.get('ref', ''), d.get('cat', ''), d.get('supplier', ''), num(d.get('buy'), p['buy']), num(d.get('sell'), p['sell']), d.get('unit') or p['unit'], num(d.get('alert'), 5), i))
        audit('Produit modifié', p['name'])
    db().commit(); return jsonify(ok=True)

@app.post('/api/products/<int:i>/restock')
@api()
def restock(i):
    p = q('select * from products where id=? and biz=? and active=1', (i, g.b['id']), one=True); n = num((request.json or {}).get('qty'))
    if not p or n <= 0: return err('Quantité invalide')
    db().execute('update products set qty=qty+? where id=?', (n, i))
    db().execute('insert into stock_moves(biz,product_id,qty,type,ref,created) values(?,?,?,?,?,?)', (g.b['id'], i, n, 'RÉAPPROVISIONNEMENT', '', time.time()))
    audit('Réapprovisionnement', f"{p['name']} +{n:g}"); db().commit(); return jsonify(ok=True)

@app.route('/api/customers', methods=['GET', 'POST'])
@api()
def customers():
    b = g.b['id']
    if request.method == 'POST':
        d = request.json or {}
        if not (d.get('name') or '').strip(): return err('Le nom du client est requis')
        c = db().execute('insert into customers(biz,name,phone,created) values(?,?,?,?)', (b, d['name'].strip(), d.get('phone', ''), time.time()))
        audit('Client créé', d['name']); db().commit(); return jsonify(id=c.lastrowid)
    return jsonify([dict(x) for x in q('''select c.*, coalesce((select sum(total) from sales where customer_id=c.id),0) spent,
        coalesce((select sum(amount-paid) from debts where customer_id=c.id),0) debt from customers c where biz=? order by id desc''', (b,))])

@app.route('/api/sales', methods=['GET', 'POST'])
@api()
def sales():
    b = g.b['id']
    if request.method == 'GET':
        out = []
        for s in q('select s.*, c.name customer from sales s left join customers c on c.id=s.customer_id where s.biz=? order by s.id desc limit 100', (b,)):
            x = dict(s); x['payments'] = [dict(p) for p in q('select method,amount from sale_payments where sale_id=?', (s['id'],))]; out.append(x)
        return jsonify(out)
    d = request.json or {}; items = []; sub = 0
    for it in d.get('items', []):
        p = q('select * from products where id=? and biz=? and active=1', (it.get('id'), b), one=True); n = num(it.get('qty'))
        if not p or n <= 0: return err('Produit ou quantité invalide')
        if p['qty'] < n: return err(f"Stock insuffisant pour {p['name']} : {p['qty']:g} {p['unit']} disponible(s)")
        items.append((p, n)); sub += p['sell'] * n
    if not items: return err('Le panier est vide')
    disc = min(max(0, num(d.get('discount'))), sub); total = sub - disc
    pays = [(x.get('method'), num(x.get('amount'))) for x in d.get('payments', []) if num(x.get('amount')) > 0]
    if any(m not in METHODS for m, _ in pays): return err('Mode de paiement invalide')
    if abs(sum(a for _, a in pays) - total) > 0.5: return err(f'Le total des paiements doit être égal à {fmt(total)} FCFA')
    credit = sum(a for m, a in pays if m == 'Crédit'); cust = d.get('customer_id') or None
    if cust and not q('select 1 from customers where id=? and biz=?', (cust, b), one=True): return err('Client introuvable')
    if credit > 0 and not cust: return err('Choisissez un client pour une vente à crédit')
    try:
        c = db(); now = time.time(); n_ = S('select count(*) from sales where biz=?', (b,)) + 1; ref = f"{time.strftime('%Y')}-{n_:04d}"
        sid = c.execute('insert into sales(biz,num,customer_id,subtotal,discount,total,created) values(?,?,?,?,?,?,?)', (b, ref, cust, sub, disc, total, now)).lastrowid; cost = 0
        for p, n in items:
            c.execute('insert into sale_items(sale_id,product_id,name,qty,price,cost) values(?,?,?,?,?,?)', (sid, p['id'], p['name'], n, p['sell'], p['buy']))
            c.execute('update products set qty=qty-? where id=?', (n, p['id']))
            c.execute('insert into stock_moves(biz,product_id,qty,type,ref,created) values(?,?,?,?,?,?)', (b, p['id'], -n, 'VENTE', ref, now)); cost += p['buy'] * n
        c.execute('update sales set cost=? where id=?', (cost, sid))
        for m, a in pays:
            c.execute('insert into sale_payments(sale_id,method,amount) values(?,?,?)', (sid, m, a))
            if m == 'Crédit': c.execute('insert into debts(biz,customer_id,sale_id,amount,created) values(?,?,?,?,?)', (b, cust, sid, a, now))
            else: c.execute('insert into cash(biz,type,amount,method,cat,label,ref_type,ref_id,created) values(?,?,?,?,?,?,?,?,?)', (b, 'IN', a, m, 'Vente', f'Vente {ref}', 'sale', sid, now))
        audit('Vente enregistrée', f'{ref} · {fmt(total)} FCFA'); c.commit()
    except Exception:
        db().rollback(); raise
    return jsonify(id=sid, num=ref, total=total, paid=total - credit, credit=credit)

@app.route('/api/expenses', methods=['GET', 'POST'])
@api()
def expenses():
    b = g.b['id']
    if request.method == 'POST':
        d = request.json or {}; a = num(d.get('amount')); m = d.get('method') if d.get('method') in METHODS[:3] else 'Espèces'
        if a <= 0 or not (d.get('cat') or '').strip(): return err('Catégorie et montant requis')
        try:
            now = time.time(); e = db().execute('insert into expenses(biz,cat,label,amount,method,created) values(?,?,?,?,?,?)', (b, d['cat'], d.get('label', ''), a, m, now)).lastrowid
            db().execute('insert into cash(biz,type,amount,method,cat,label,ref_type,ref_id,created) values(?,?,?,?,?,?,?,?,?)', (b, 'OUT', a, m, d['cat'], d.get('label') or d['cat'], 'expense', e, now))
            audit('Dépense enregistrée', f"{d['cat']} · {fmt(a)} FCFA"); db().commit()
        except Exception:
            db().rollback(); raise
        return jsonify(id=e)
    return jsonify([dict(x) for x in q('select * from expenses where biz=? order by id desc limit 200', (b,))])

@app.delete('/api/expenses/<int:i>')
@api()
def del_expense(i):
    if not q('select 1 from expenses where id=? and biz=?', (i, g.b['id']), one=True): return err('Dépense introuvable', 404)
    db().execute('delete from cash where ref_type=? and ref_id=? and biz=?', ('expense', i, g.b['id'])); db().execute('delete from expenses where id=?', (i,))
    audit('Dépense supprimée', str(i)); db().commit(); return jsonify(ok=True)

@app.get('/api/cash')
@api()
def cash():
    b = g.b['id']; rows = [dict(x) for x in q('select * from cash where biz=? order by id desc limit 200', (b,))]
    by = {m: S("select sum(case type when 'IN' then amount else -amount end) from cash where biz=? and method=?", (b, m)) for m in METHODS[:3]}
    return jsonify(rows=rows, by_method=by, balance=sum(by.values()), inn=S("select sum(amount) from cash where biz=? and type='IN'", (b,)), out=S("select sum(amount) from cash where biz=? and type='OUT'", (b,)))

@app.get('/api/stats')
@api()
def stats():
    b = g.b['id']; now = time.time(); day0 = now - now % DAY; t = time.gmtime(now); p = request.args.get('p', 'mois')
    since = {'jour': day0, 'semaine': day0 - 6 * DAY, 'mois': time.mktime((t.tm_year, t.tm_mon, 1, 0, 0, 0, 0, 0, 0)) - time.timezone,
             'annee': time.mktime((t.tm_year, 1, 1, 0, 0, 0, 0, 0, 0)) - time.timezone, 'tout': 0}.get(p, 0)
    ca = S('select sum(total) from sales where biz=? and created>=?', (b, since)); cost = S('select sum(cost) from sales where biz=? and created>=?', (b, since))
    dep = S('select sum(amount) from expenses where biz=? and created>=?', (b, since)); brut = ca - cost; net = brut - dep
    days = []
    for k in range(6, -1, -1):
        a, z = day0 - k * DAY, day0 - (k - 1) * DAY
        c_ = S('select sum(total) from sales where biz=? and created>=? and created<?', (b, a, z)); co = S('select sum(cost) from sales where biz=? and created>=? and created<?', (b, a, z))
        de = S('select sum(amount) from expenses where biz=? and created>=? and created<?', (b, a, z)); days.append(dict(ca=c_, dep=de, net=c_ - co - de))
    pr = q('select * from products where biz=? and active=1', (b,))
    return jsonify(period=p, ca=ca, cost=cost, brut=brut, dep=dep, net=net, marge=(brut / ca * 100) if ca else 0, nb_sales=S('select count(*) from sales where biz=? and created>=?', (b, since)),
        clients=S('select count(*) from customers where biz=?', (b,)), debts=S('select sum(amount-paid) from debts where biz=?', (b,)),
        cash=S("select sum(case type when 'IN' then amount else -amount end) from cash where biz=?", (b,)),
        stock_cost=sum(x['buy'] * x['qty'] for x in pr), stock_value=sum(x['sell'] * x['qty'] for x in pr), days=days,
        top=[dict(x) for x in q('select si.name, sum(si.qty) qty, sum(si.qty*si.price) rev from sale_items si join sales s on s.id=si.sale_id where s.biz=? and s.created>=? group by si.name order by rev desc limit 5', (b, since))],
        alerts=[dict(name=x['name'], qty=x['qty'], unit=x['unit'], state='Rupture' if x['qty'] <= 0 else 'Faible') for x in pr if x['qty'] <= x['alert']], sector=g.b['sector'])

if __name__ == '__main__': app.run(debug=True)
